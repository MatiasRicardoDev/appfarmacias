$('#img_cel_farmacia_turno').click(function(){
    $('#app').load('./views/turno.html');
    console.log('clicked')
})